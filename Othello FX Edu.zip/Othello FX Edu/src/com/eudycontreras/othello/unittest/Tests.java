package com.eudycontreras.othello.unittest;

public class Tests {
	
	public Tests(){

	}
	
	
	
	public void test1(){

	}
	
	public static void main(String[] args){
		new Tests().test1();
	}
	
}
