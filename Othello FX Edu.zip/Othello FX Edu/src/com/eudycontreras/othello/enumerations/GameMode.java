package com.eudycontreras.othello.enumerations;

public enum GameMode {

	HUMAN_VS_HUMAN,
	HUMAN_VS_AGENT,
	AGENT_VS_AGENT
}
