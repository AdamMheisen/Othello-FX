package main;

public class app {
    public static void main(String[] args) {
        AgentManager.main(args);
    }
}
